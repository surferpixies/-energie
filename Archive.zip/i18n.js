(() => {
  'use strict';
  const SUPPORTED=['fr-CA','fr-FR','en'];
  const stored=localStorage.getItem('energieLocale');
  const browser=(navigator.languages||[navigator.language||'fr-CA']).find(l=>/^fr-FR/i.test(l)||/^fr/i.test(l)||/^en/i.test(l));
  const locale=SUPPORTED.includes(stored)?stored:(/^fr-FR/i.test(browser||'')?'fr-FR':/^en/i.test(browser||'')?'en':'fr-CA');
  window.ENERGIE_LOCALE=locale;
  document.documentElement.lang=locale;

  const frFR={
    'Journal':'Journal','Historique':'Historique','Observations':'Observations','Profil':'Profil',
    'Déjeuner':'Petit-déjeuner','Dîner':'Déjeuner','Souper':'Dîner','Collation':'En-cas','Boisson':'Boisson',
    'Courriel':'E-mail','Adresse courriel':'Adresse e-mail','Mot de passe':'Mot de passe',
    'Sauvegarde infonuagique':'Sauvegarde dans le cloud','Sauvegarde en ligne':'Sauvegarde en ligne',
    'Repas enregistrés':'Repas enregistrés','Objectif d\'eau':"Objectif d’eau",'Nombre de gouttes affichées':'Nombre de gouttes affichées',
    'Rappels de ressenti':'Rappels de ressenti','Repas concernés':'Repas concernés','Délai après le repas':'Délai après le repas',
    'Autoriser les notifications':'Autoriser les notifications','Mon repas':'Mon repas','Ajouter un repas':'Ajouter un repas','Modifier le repas':'Modifier le repas',
    "Copier le déjeuner d'hier":"Copier le petit-déjeuner d’hier",'Choisir un repas favori':'Choisir un repas favori',
    'Choisir un favori…':'Choisir un favori…','Type de repas':'Type de repas','Heure':'Heure',
    'Ce que tu as mangé ou bu':'Ce que vous avez mangé ou bu','Énergie avant le repas':'Énergie avant le repas',
    'Photo facultative':'Photo facultative','Notes facultatives':'Notes facultatives','Enregistrer':'Enregistrer',
    'Sommeil de la nuit dernière':'Sommeil de la nuit dernière','Nombre d’heures':"Nombre d’heures",'Nombre d\'heures':"Nombre d’heures",
    'Ajouter une activité':'Ajouter une activité','Choisis une activité':'Choisissez une activité','Durée en minutes':'Durée en minutes',
    'Après le repas':'Après le repas','Comment te sens-tu?':'Comment vous sentez-vous ?','Qu’as-tu ressenti?':'Qu’avez-vous ressenti ?',
    'Sélectionne tous les éléments qui s’appliquent.':'Sélectionnez tous les éléments qui s’appliquent.',
    'Autre chose?':'Autre chose ?','Enregistrer le ressenti':'Enregistrer le ressenti',
    'Bienvenue':'Bienvenue','J’ai compris':'J’ai compris','Ne plus afficher ce message automatiquement':'Ne plus afficher ce message automatiquement',
    'Profil et préférences':'Profil et préférences','Protège ton historique':'Protégez votre historique',
    'La copie locale seule peut disparaître sur iPhone.':'La copie locale seule peut disparaître sur iPhone.',
    'Se connecter':'Se connecter','Se déconnecter':'Se déconnecter','Synchroniser':'Synchroniser',
    'Observations et recommandations':'Observations et recommandations','Insights personnels':'Observations personnelles',
    'Suggestions générales':'Suggestions générales','Afficher les sources':'Afficher les sources',
    'Message d’information':'Message d’information','Afficher':'Afficher','Sauvegarde supplémentaire':'Sauvegarde supplémentaire',
    'Exporter JSON':'Exporter en JSON','Importer JSON':'Importer un JSON','Mes favoris':'Mes favoris',
    'À noter':'À renseigner','À ajouter':'À ajouter','Plusieurs possibles':'Plusieurs possibles','Aucun repas pour cette journée.':'Aucun repas pour cette journée.',
    'Repas':'Repas','Sommeil':'Sommeil','Activité':'Activité','Hydratation':'Hydratation','Énergie avant':'Énergie avant',
    'Aujourd’hui':"Aujourd’hui",'Hier':'Hier','Jour précédent':'Jour précédent','Jour suivant':'Jour suivant',
    'Non connecté':'Non connecté','Hors ligne':'Hors ligne','Erreur synchro':'Erreur de synchronisation','Sauvegardé ☁️':'Sauvegardé ☁️',
    'Marche':'Marche','Course':'Course à pied','Vélo':'Vélo','Musculation':'Renforcement musculaire','Yoga':'Yoga','Natation':'Natation','Autre':'Autre',
    'Mal de tête':'Mal de tête','Mal de ventre':'Mal au ventre','Ballonnements':'Ballonnements','Nausées':'Nausées','Fatigue':'Fatigue',
    'Étourdissements':'Vertiges','Reflux':'Reflux','Gaz':'Gaz','Plein d’énergie':'Plein d’énergie','Bonne humeur':'Bonne humeur',
    'Bonne concentration':'Bonne concentration','Digestion facile':'Digestion facile','Je me sens bien':'Je me sens bien',
    'Langue':'Langue','Langue de l’application':'Langue de l’application','Français (Canada)':'Français (Canada)','Français (France)':'Français (France)','English':'English'
  };
  const en={
    'Journal':'Journal','Historique':'History','Observations':'Insights','Observations':'Insights','Profil':'Profile',
    'Déjeuner':'Breakfast','Dîner':'Lunch','Souper':'Dinner','Collation':'Snack','En-cas':'Snack','Boisson':'Drink','Repas':'Meal',
    'Mon repas':'My meal','Ajouter un repas':'Add a meal','Modifier le repas':'Edit meal','Choisir un repas favori':'Choose a favorite meal',
    'Choisir un favori…':'Choose a favorite…','Type de repas':'Meal type','Le type de repas':'Meal type','Heure':'Time','Ce que tu as mangé ou bu':'What you ate or drank',
    'Ce que vous avez mangé ou bu':'What you ate or drank','Énergie avant le repas':'Energy before the meal','Photo facultative':'Optional photo',
    'Retirer la photo':'Remove photo','Notes facultatives':'Optional notes','Enregistrer':'Save',"Copier le déjeuner d'hier":"Copy yesterday’s breakfast",
    'Repos':'Rest','Sommeil':'Sleep','Sommeil de la nuit dernière':'Last night’s sleep','Inscris simplement la durée totale approximative.':'Simply enter the approximate total duration.',
    "Nombre d'heures":'Number of hours','Nombre d’heures':'Number of hours','Enregistrer le sommeil':'Save sleep',
    'Mouvement':'Movement','Ajouter une activité':'Add an activity','Choisis une activité':'Choose an activity','Choisissez une activité':'Choose an activity',
    'Durée en minutes':'Duration in minutes','Intensité':'Intensity','Faible':'Low','Modérée':'Moderate','Élevée':'High','Calories estimées':'Estimated calories','Calories mesurées':'Measured calories','Activités enregistrées':'Saved activities',"Ajouter l'activité":'Add activity',
    'Marche':'Walk','Course':'Run','Course à pied':'Run','Vélo':'Cycling','Musculation':'Strength training','Renforcement musculaire':'Strength training','Yoga':'Yoga','Natation':'Swimming','Autre':'Other',
    'Après le repas':'After the meal','Ressenti':'Feeling','Comment te sens-tu?':'How do you feel?','Comment vous sentez-vous ?':'How do you feel?',
    'Qu’as-tu ressenti?':'What did you notice?','Qu’avez-vous ressenti ?':'What did you notice?','Sélectionne tous les éléments qui s’appliquent.':'Select everything that applies.',
    'Sélectionnez tous les éléments qui s’appliquent.':'Select everything that applies.','Autre chose?':'Anything else?','Autre chose ?':'Anything else?',
    'Enregistrer le ressenti':'Save feeling','Notes facultatives':'Optional notes','Bienvenue':'Welcome','J’ai compris':'I understand',
    'Ne plus afficher ce message automatiquement':'Do not show this message automatically again','Transparence':'Transparency','Pourquoi je vois ceci?':'Why am I seeing this?',
    'Sauvegarde infonuagique':'Cloud backup','Sauvegarde dans le cloud':'Cloud backup','Connexion':'Sign in','Créer un compte':'Create an account',
    'Adresse courriel':'Email address','Adresse e-mail':'Email address','Mot de passe':'Password','Confirmer le mot de passe':'Confirm password',
    'Me connecter':'Sign in','Créer mon compte':'Create my account','Mot de passe oublié':'Forgot password',
    'Journal':'Journal','Historique':'History','Profil et préférences':'Profile and preferences','Protège ton historique':'Protect your history','Protégez votre historique':'Protect your history',
    'La copie locale seule peut disparaître sur iPhone.':'A local-only copy may disappear from your iPhone.','Compte connecté':'Connected account',
    'Synchroniser':'Sync','Se déconnecter':'Sign out','Sauvegarde en ligne':'Online backup','Se connecter':'Sign in',
    'Observations et recommandations':'Insights and recommendations','Tu gardes le contrôle sur ce qui apparaît dans le tableau de bord.':'You control what appears in your dashboard.',
    'Insights personnels':'Personal insights','Observations personnelles':'Personal insights','Tendances calculées à partir de ton historique':'Patterns calculated from your history',
    'Observations nutritionnelles':'Nutrition observations','Estimations prudentes selon les descriptions saisies':'Careful estimates based on your descriptions',
    'Suggestions générales':'General suggestions','Conseils facultatifs et non moralisateurs':'Optional, non-judgmental suggestions','Afficher les sources':'Show sources',
    'Message d’information':'Information notice','Afficher':'Show','Rappels de ressenti':'Feeling reminders','Repas concernés':'Meals included',
    'Délai après le repas':'Delay after meal','Autoriser les notifications':'Allow notifications','Objectif d’eau':'Water goal',"Objectif d'eau":'Water goal',
    'Nombre de gouttes affichées':'Number of drops displayed','Mes favoris':'My favorites','Sauvegarde supplémentaire':'Additional backup',
    'Exporter JSON':'Export JSON','Exporter en JSON':'Export JSON','Importer JSON':'Import JSON','Importer un JSON':'Import JSON',
    'Aujourd’hui':'Today','Hier':'Yesterday','Jour précédent':'Previous day','Jour suivant':'Next day','Journal':'Journal','repas principaux':'main meals',
    'Commence par ton prochain repas':'Start with your next meal','À noter':'To add','À renseigner':'To add','À ajouter':'To add','Plusieurs possibles':'Multiple allowed',
    'Sommeil':'Sleep','Activité':'Activity','Hydratation':'Hydration','Énergie avant':'Energy before','Repas enregistrés':'Saved meals','Aucun repas pour cette journée.':'No meals saved for this day.',
    'Non connecté':'Not signed in','Hors ligne':'Offline','Erreur synchro':'Sync error','Sauvegardé ☁️':'Saved ☁️','à synchroniser':'to sync',
    'Mal de tête':'Headache','Mal de ventre':'Stomach ache','Mal au ventre':'Stomach ache','Ballonnements':'Bloating','Nausées':'Nausea','Fatigue':'Fatigue',
    'Étourdissements':'Dizziness','Vertiges':'Dizziness','Reflux':'Reflux','Gaz':'Gas','Plein d’énergie':'Full of energy','Bonne humeur':'Good mood',
    'Bonne concentration':'Good focus','Digestion facile':'Easy digestion','Je me sens bien':'I feel good',
    'Langue':'Language','Langue de l’application':'App language','Français (Canada)':'French (Canada)','Français (France)':'French (France)','English':'English'
  };

  Object.assign(frFR, {
    'Changer le thème':'Changer le thème','Fermer':'Fermer','Aperçu':'Aperçu','Repos':'Repos','Mouvement':'Mouvement',
    'Type d’activité':"Type d’activité",'Ressenti général':'Ressenti général','Sécurité':'Sécurité','Choisir un mot de passe':'Choisir un mot de passe',
    'Presque terminé':'Presque terminé','Enregistrer le mot de passe':'Enregistrer le mot de passe',
    'Connexion directe dans l’app iPhone':"Connexion directe dans l’application iPhone",'Au moins 8 caractères':'Au moins 8 caractères','Répète le mot de passe':'Répétez le mot de passe',
    'Mot de passe oublié ou compte créé avec un lien magique?':'Mot de passe oublié ou compte créé avec un lien magique ?',
    'Cette application sert à suivre tes repas, ton niveau d’énergie avant de manger et certaines habitudes afin de t’aider à observer des tendances personnelles.':
      'Cette application sert à suivre vos repas, votre niveau d’énergie avant de manger et certaines habitudes afin de vous aider à observer des tendances personnelles.',
    'Un outil d’observation, pas un avis médical':'Un outil d’observation, pas un avis médical',
    'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas un lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un nutritionniste ou d’un autre professionnel de la santé.':
      'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas un lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un nutritionniste ou d’un autre professionnel de santé.',
    'Les estimations nutritionnelles peuvent être incomplètes, surtout lorsque l’application ne connaît pas les portions ni les valeurs nutritives exactes.':
      'Les estimations nutritionnelles peuvent être incomplètes, notamment lorsque l’application ne connaît pas les portions ni les valeurs nutritionnelles exactes.',
    'Ce mot de passe permettra la connexion directe dans l’app installée.':'Ce mot de passe permettra la connexion directe dans l’application installée.',
    'Ex. bagel, œufs et café':'Ex. : tartines, œufs et café','Contexte, digestion, humeur…':'Contexte, digestion, humeur…','Ex. 45':'Ex. : 45',
    'Commence par ton prochain repas':'Commencez par votre prochain repas','Cette carte repose uniquement sur tes données personnelles.':'Cette carte repose uniquement sur vos données personnelles.',
    'Aucun ressenti en attente':'Aucun ressenti en attente','Tu peux le modifier depuis le repas.':'Vous pouvez le modifier depuis le repas.',
    'Les rappels apparaîtront après tes repas principaux.':'Les rappels apparaîtront après vos repas principaux.',
    'Ajouter un ressenti':'Ajouter un ressenti','Modifier le ressenti':'Modifier le ressenti','Supprimer':'Supprimer','Ajouter aux favoris':'Ajouter aux favoris',
    'Aucune activité enregistrée pour cette journée.':'Aucune activité enregistrée pour cette journée.',
    'Ajoute un repas existant à tes favoris avec l’étoile.':'Ajoutez un repas existant à vos favoris grâce à l’étoile.','Aucun résultat.':'Aucun résultat.',
    'favoris':'favoris','verres notés':'verres enregistrés','jours suivis':'jours suivis','sommeil moyen':'sommeil moyen'
  });
  Object.assign(en, {
    'Changer le thème':'Change theme','Fermer':'Close','Aperçu':'Preview','Repos':'Rest','Mouvement':'Movement',
    'Type d’activité':'Activity type','Ressenti général':'Overall feeling','Sécurité':'Security','Choisir un mot de passe':'Choose a password',
    'Presque terminé':'Almost done','Enregistrer le mot de passe':'Save password','Connexion directe dans l’app iPhone':'Sign in directly in the iPhone app',
    'Au moins 8 caractères':'At least 8 characters','Répète le mot de passe':'Repeat the password',
    'Mot de passe oublié ou compte créé avec un lien magique?':'Forgot your password or created your account with a magic link?',
    'Cette application sert à suivre tes repas, ton niveau d’énergie avant de manger et certaines habitudes afin de t’aider à observer des tendances personnelles.':
      'This app helps you track meals, your energy before eating, and selected habits so you can notice personal patterns over time.',
    'Un outil d’observation, pas un avis médical':'A tracking tool, not medical advice',
    'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas un lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un nutritionniste ou d’un autre professionnel de la santé.':
      'Insights and suggestions are for informational purposes only. They do not provide a diagnosis, prove cause and effect, or replace advice from a doctor, dietitian, or other healthcare professional.',
    'Les estimations nutritionnelles peuvent être incomplètes, surtout lorsque l’application ne connaît pas les portions ni les valeurs nutritives exactes.':
      'Nutrition estimates may be incomplete, especially when serving sizes and exact nutrition facts are unknown.',
    'Ce mot de passe permettra la connexion directe dans l’app installée.':'This password will let you sign in directly from the installed app.',
    'Ex. bagel, œufs et café':'E.g. bagel, eggs, and coffee','Contexte, digestion, humeur…':'Context, digestion, mood…','Ex. 45':'E.g. 45',
    'Commence par ton prochain repas':'Start with your next meal','Cette carte repose uniquement sur tes données personnelles.':'This card is based only on your personal data.',
    'Aucun ressenti en attente':'No pending check-ins','Tu peux le modifier depuis le repas.':'You can edit it from the meal.',
    'Les rappels apparaîtront après tes repas principaux.':'Reminders will appear after your main meals.',
    'Ajouter un ressenti':'Add a check-in','Modifier le ressenti':'Edit check-in','Supprimer':'Delete','Ajouter aux favoris':'Add to favorites',
    'Aucune activité enregistrée pour cette journée.':'No activity saved for this day.',
    'Ajoute un repas existant à tes favoris avec l’étoile.':'Use the star on a saved meal to add it to your favorites.','Aucun résultat.':'No results.',
    'favoris':'favorites','verres notés':'glasses logged','jours suivis':'days tracked','sommeil moyen':'average sleep',
    'Très faible':'Very low','Faible':'Low','Moyenne':'Moderate','Élevée':'High','Très élevée':'Very high','Préliminaire':'Preliminary',
    'Soirée':'Evening','Beau temps ce matin':'Clear morning','Beau temps cet après-midi':'Clear afternoon','Pluie aujourd’hui':'Rain today','Neige aujourd’hui':'Snow today',
    'Code météo absent':'Weather code unavailable','Géolocalisation indisponible':'Location unavailable',
    'Notifications autorisées.':'Notifications allowed.','Les notifications ne sont pas autorisées dans ce navigateur.':'Notifications are not allowed in this browser.',
    'Choisis un type d’activité.':'Choose an activity type.','Indique une durée en minutes.':'Enter a duration in minutes.',
    'Aucun déjeuner trouvé hier.':'No breakfast was found yesterday.','Aucun symptôme ou état sélectionné. Enregistrer seulement la note globale?':'No symptom or positive state selected. Save only the overall rating?',
    'Ce repas est déjà dans tes favoris.':'This meal is already in your favorites.','Nom du repas favori :':'Favorite meal name:',
    'Repas ajouté aux favoris ⭐':'Meal added to favorites ⭐','Supprimer ce repas?':'Delete this meal?',
    'Après l’inscription, confirme le courriel de Supabase.':'After signing up, confirm the email sent by Supabase.',
    'La connexion se fait directement dans l’application.':'You sign in directly in the app.','Connexion…':'Signing in…','Création du compte…':'Creating account…',
    'Le mot de passe doit contenir au moins 8 caractères.':'The password must contain at least 8 characters.','Les deux mots de passe ne sont pas identiques.':'The passwords do not match.',
    'Compte créé. Confirme le courriel, puis connecte-toi.':'Account created. Confirm your email, then sign in.','Entre d’abord ton adresse courriel.':'Enter your email address first.',
    'Courriel de récupération envoyé.':'Recovery email sent.','Les mots de passe ne sont pas identiques.':'The passwords do not match.','Minimum 8 caractères.':'Minimum 8 characters.',
    'Mot de passe enregistré.':'Password saved.','Importer aussi cette copie dans Supabase?':'Import this copy into Supabase too?','Ce fichier JSON ne peut pas être importé.':'This JSON file cannot be imported.',
    'Courriel ou mot de passe incorrect.':'Incorrect email or password.','Confirme d’abord ton adresse courriel.':'Confirm your email address first.',
    'Ce courriel possède déjà un compte.':'An account already exists for this email.','Trop de tentatives rapprochées. Attends un peu puis réessaie.':'Too many attempts in a short time. Wait a moment and try again.',
    'Une erreur est survenue.':'An error occurred.','Les observations sont désactivées dans les paramètres.':'Insights are disabled in settings.',
    'Continue d’enregistrer tes repas pour obtenir des observations.':'Keep logging meals to unlock insights.',
    'Ce résumé repose uniquement sur les données que tu as enregistrées.':'This summary is based only on the data you recorded.',
    'Cette journée contribue progressivement à mieux décrire tes habitudes.':'This day gradually adds context to your habits.',
    'Journée associée à plus d’énergie':'Day associated with higher energy','Énergie observée avant certains repas':'Energy observed before certain meals',
    'Ce que j’apprends sur toi':'What I’m learning about you','Tu prends un déjeuner presque tous les jours.':'You eat breakfast almost every day.','Tu choisis souvent un fruit comme collation.':'You often choose fruit as a snack.','Les légumes sont présents dans la majorité de tes soupers.':'Vegetables are present in most of your dinners.','Une source de protéines apparaît dans la plupart de tes repas principaux.':'A protein source appears in most of your main meals.','Ton hydratation est très constante les jours où tu la documentes.':'Your hydration is very consistent on the days you track it.','Ton journal devient assez complet pour faire ressortir progressivement des habitudes plus utiles.':'Your journal is becoming complete enough to gradually reveal more useful habits.','Aliments possiblement plus salés':'Foods that may be higher in sodium','Aliments possiblement plus sucrés':'Foods that may be higher in sugar',
    'Gras saturés à surveiller dans les choix fréquents':'Saturated fat in frequently logged foods','Certains aliments notés fréquemment peuvent contenir davantage de gras saturés. Il ne s’agit pas d’un jugement sur un repas; la variété au fil du temps est ce qui compte.':'Some frequently logged foods may contain more saturated fat. This is not a judgment about any meal; variety over time is what matters.','Peu de végétaux repérés dans les descriptions':'Few plant foods detected in descriptions',
    'Organisation mondiale de la Santé — Alimentation saine':'World Health Organization — Healthy diet','Santé Canada — Guide alimentaire canadien':"Health Canada — Canada's Food Guide",
    'Santé Canada — Limiter les aliments hautement transformés':'Health Canada — Limit highly processed foods','Santé Canada — Symbole nutritionnel sur le devant de l’emballage':'Health Canada — Front-of-package nutrition symbol'
  });

  Object.assign(frFR, {
    'Smart Timeline':'Chronologie intelligente','Ton historique, organisé naturellement':'Votre historique, organisé naturellement',
    'Les repas sont regroupés par journée, semaine et mois pour rester faciles à consulter avec le temps.':'Les repas sont regroupés par jour, semaine et mois pour rester faciles à consulter au fil du temps.',
    'Ton parcours':'Votre parcours','Résumé de la journée':'Résumé de la journée','Période':'Période','PÉRIODE':'PÉRIODE','Tout':'Tout','7 jours':'7 jours','Ce mois':'Ce mois','Cette année':'Cette année',
    'Type de repas':'Type de repas','⭐ Favoris':'⭐ Favoris','Énergie faible':'Énergie faible','Énergie élevée':'Énergie élevée','Chronologie':'Chronologie',
    'Rechercher un aliment, une note ou une date…':'Rechercher un aliment, une note ou une date…',
    'Tableau de bord & observations':'Tableau de bord et observations','Observe tes habitudes sans jugement':'Observez vos habitudes',
    'Les cartes décrivent des tendances possibles. Elles ne posent aucun diagnostic et ne prouvent jamais qu’un aliment cause un effet.':'Les cartes décrivent des tendances possibles. Elles ne posent aucun diagnostic et ne prouvent jamais qu’un aliment provoque un effet.',
    'Repas — 7 jours':'Repas — 7 jours','Repas au total':'Repas au total','Heure moyenne':'Heure moyenne','Énergie avant — jours récents':'Énergie avant — jours récents',
    'Pas encore assez de données.':'Pas encore assez de données.','énergie faible':'énergie faible','énergie élevée':'énergie élevée','Repas les plus fréquents':'Repas les plus fréquents',
    'Ajoute quelques repas pour voir le classement.':'Ajoutez quelques repas pour voir le classement.','🧠 Observations':'🧠 Observations',
    'Mode aperçu activé':'Mode aperçu activé','Tes vraies données':'Vos données réelles','Des données exemples montrent la présentation. Elles ne sont jamais sauvegardées.':'Des données d’exemple illustrent la présentation. Elles ne sont jamais enregistrées.',
    'Le tableau de bord utilise seulement tes repas enregistrés.':'Le tableau de bord utilise uniquement vos repas enregistrés.','Voir mes données':'Voir mes données','Voir l’aperçu':'Voir l’aperçu',
    'Les valeurs du mode aperçu sont fictives et servent uniquement à prévisualiser la présentation.':'Les valeurs du mode aperçu sont fictives et servent uniquement à prévisualiser la présentation.',
    'repas':'repas','journées':'jours','mois':'mois','jour de suivi':'jour de suivi','jours de suivi':'jours de suivi','Depuis le':'Depuis le',
    'fatigue moyenne':'fatigue moyenne','Sources générales':'Sources générales','Observation nutritionnelle estimée':'Observation nutritionnelle estimée',
    'Ambiance du jour':'Ambiance du jour','Beau temps ce matin':'Beau temps ce matin','Pluie aujourd’hui':'Pluie aujourd’hui','Neige aujourd’hui':'Neige aujourd’hui'
  });
  Object.assign(en, {
    'Smart Timeline':'Smart Timeline','Ton historique, organisé naturellement':'Your history, naturally organized',
    'Les repas sont regroupés par journée, semaine et mois pour rester faciles à consulter avec le temps.':'Meals are grouped by day, week, and month so they stay easy to browse over time.',
    'Ton parcours':'Your journey','Résumé de la journée':'Daily summary','Période':'Period','PÉRIODE':'PERIOD','Tout':'All','7 jours':'7 days','Ce mois':'This month','Cette année':'This year',
    'Type de repas':'Meal type','Le type de repas':'Meal type','⭐ Favoris':'⭐ Favorites','Énergie faible':'Low energy','Énergie élevée':'High energy','Chronologie':'Timeline',
    'Rechercher un aliment, une note ou une date…':'Search food, notes, or a date…',
    'Tableau de bord & observations':'Dashboard & insights','Observe tes habitudes sans jugement':'Notice your habits',
    'Les cartes décrivent des tendances possibles. Elles ne posent aucun diagnostic et ne prouvent jamais qu’un aliment cause un effet.':'These cards describe possible patterns. They do not diagnose anything or prove that a food causes an effect.',
    'Repas — 7 jours':'Meals — 7 days','Repas au total':'Total meals','Heure moyenne':'Average time','Énergie avant — jours récents':'Energy before meals — recent days',
    'Pas encore assez de données.':'Not enough data yet.','énergie faible':'low energy','énergie élevée':'high energy','Repas les plus fréquents':'Most frequent meals',
    'Ajoute quelques repas pour voir le classement.':'Log a few meals to see the ranking.','🧠 Observations':'🧠 Insights',
    'Mode aperçu activé':'Preview mode on','Tes vraies données':'Your actual data','Des données exemples montrent la présentation. Elles ne sont jamais sauvegardées.':'Sample data shows how the dashboard will look. It is never saved.',
    'Le tableau de bord utilise seulement tes repas enregistrés.':'The dashboard uses only your saved meals.','Voir mes données':'View my data','Voir l’aperçu':'View preview',
    'Les valeurs du mode aperçu sont fictives et servent uniquement à prévisualiser la présentation.':'Preview values are fictional and are shown only to demonstrate the presentation.',
    'repas':'meals','journées':'days','mois':'months','jour de suivi':'day tracked','jours de suivi':'days tracked','Depuis le':'Since',
    'fatigue moyenne':'average fatigue','Sources générales':'General sources','Observation nutritionnelle estimée':'Estimated nutrition observation',
    'Ambiance du jour':'Today’s atmosphere','Beau temps ce matin':'Clear this morning','Pluie aujourd’hui':'Rain today','Neige aujourd’hui':'Snow today',
    'Aucun repas pour cette journée.':'No meals saved for this day.','Tableau de bord':'Dashboard','Observations':'Insights','carte':'card','cartes':'cards'
  });


  // V2.4.3 — nettoyage UX du Journal et derniers correctifs de traduction ciblés.
  Object.assign(en, {
    'Local':'Local','Changer le thème':'Change theme','Navigation principale':'Main navigation','Fermer':'Close','Aperçu':'Preview',
    'Un outil d’observation, pas un avis médical':'A tracking tool, not medical advice',
    'Cette application sert à suivre tes repas, ton niveau d’énergie avant de manger et certaines habitudes afin de t’aider à observer des tendances personnelles.':'This app helps you track meals, your energy before eating, and selected habits so you can notice personal patterns.',
    'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas un lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un nutritionniste ou d’un autre professionnel de la santé.':'Insights and suggestions are informational. They do not provide a diagnosis, prove cause and effect, or replace advice from a physician, dietitian, or other health professional.',
    'Connexion directe dans l’app iPhone':'Sign in directly in the iPhone app','Mot de passe oublié ou compte créé avec un lien magique?':'Forgot your password or created your account with a magic link?',
    'Sécurité':'Security','Choisir un mot de passe':'Choose a password','Presque terminé':'Almost done','Nouveau mot de passe':'New password',
    'Revoir les limites et l’utilisation prévue de l’application':'Review the app’s limits and intended use',
    'Choisis si et quand l’application te rappelle de noter ton ressenti après un repas.':'Choose whether and when the app reminds you to record how you feel after a meal.',
    'Désactive ceci pour ne recevoir aucun rappel':'Turn this off to receive no reminders',
    'Sur le Web, les rappels système dépendent des permissions du navigateur et peuvent nécessiter que l’app soit ouverte. Les ressentis dus restent toujours visibles dans le Journal.':'On the web, system reminders depend on browser permissions and may require the app to be open. Due check-ins always remain visible in the Journal.',
    'Connecte-toi afin que les repas et favoris soient enregistrés dans Supabase.':'Sign in so your meals and favorites are saved in Supabase.',
    'La synchronisation Supabase est active.':'Supabase sync is active.','Compte connecté':'Connected account',
    'Ajoute « Pourquoi je vois ceci? » aux cartes':'Add “Why am I seeing this?” to cards',
    'Observations nutritionnelles':'Nutrition insights','Tendances calculées à partir de ton historique':'Patterns calculated from your history',
    'Estimations prudentes selon les descriptions saisies':'Careful estimates based on entered descriptions',
    'Conseils facultatifs et non moralisateurs':'Optional, non-judgmental suggestions',
    'Choisir une activité':'Choose an activity','Ajouter l\'activité':'Add activity','Ressenti général':'Overall feeling',
    'Répondre':'Respond','Utiliser':'Use','Limites importantes':'Important limitations',
    'Cette observation est automatisée et informative. Elle ne constitue ni un diagnostic, ni une preuve de causalité, ni un remplacement d’un avis professionnel.':'This automated insight is informational. It is not a diagnosis, proof of causation, or a substitute for professional advice.',
    'Cette observation utilise les données disponibles dans l’application.':'This insight uses the data available in the app.',
    'Tu es hors ligne. Les changements seront synchronisés plus tard.':'You are offline. Changes will sync later.',
    'Très faible':'Very low','Faible':'Low','Moyenne':'Moderate','Bonne':'Good','Excellente':'Excellent',
    '1 heure':'1 hour','2 heures':'2 hours','3 heures':'3 hours','Tous':'All',
    'Utilisé':'Used','fois':'times','Confiance':'Confidence','élevée':'high','moyenne':'moderate','faible':'low',
    'Repas principaux':'Main meals','repas principal':'main meal','repas principaux':'main meals',
    'journée':'day','jour':'day','jours':'days','mois':'months','Depuis':'Since',
    'Aucun ressenti en attente':'No pending check-ins','Dernier ressenti':'Latest feeling',
    '😊 Ressenti':'😊 Feeling','⭐ Mes favoris':'⭐ My favorites','Observation personnelle':'Personal insight','Observations':'Insight','Observations':'Insights','Pourquoi je vois ceci?':'Why am I seeing this?',
    'Sources générales':'General sources','Afficher les sources':'Show sources',
    'Objectif d\'eau':'Water goal','Nombre de gouttes affichées':'Number of drops displayed',
    'Sauvegarde supplémentaire':'Additional backup','copie(s) locale(s) de sécurité.':'local backup copies.',
    'Énergie V':'Energy V','Enregistrer le mot de passe':'Save password',
    'Repas concernés':'Meals included','Délai après le repas':'Delay after meal',
    'Mode aperçu activé':'Preview mode enabled','Tes vraies données':'Your real data',
    'Des données exemples montrent la présentation. Elles ne sont jamais sauvegardées.':'Sample data demonstrates the experience. It is never saved.',
    'Les observations utilisent seulement tes repas enregistrés.':'The dashboard uses only your logged meals.',
    'Repas au total':'Total meals','Résumé de la journée':'Daily summary','Chronologie':'Timeline','Période':'Period','PÉRIODE':'PERIOD',
    'Ton parcours':'Your journey','Observe tes habitudes sans jugement':'Notice your habits',
    'Observations':'Dashboard & insights','Smart Timeline':'Smart Timeline',
    'Ton historique, organisé naturellement':'Your history, naturally organized',
    'Repas — 7 jours':'Meals — 7 days','Heure moyenne':'Average time','Énergie avant — jours récents':'Energy before meals — recent days',
    'Repas les plus fréquents':'Most frequent meals','Pas encore assez de données.':'Not enough data yet.',
    'Journal':'Journal','Historique':'History','Tableau':'Insights','Profil':'Profile'
  });

  Object.assign(frFR, {
    'Changer le thème':'Changer de thème','Navigation principale':'Navigation principale','Fermer':'Fermer',
    'Cette application sert à suivre tes repas, ton niveau d’énergie avant de manger et certaines habitudes afin de t’aider à observer des tendances personnelles.':'Cette application permet de suivre vos repas, votre niveau d’énergie avant de manger et certaines habitudes afin de vous aider à observer des tendances personnelles.',
    'Un outil d’observation, pas un avis médical':'Un outil d’observation, pas un avis médical',
    'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas un lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un nutritionniste ou d’un autre professionnel de la santé.':'Les observations et suggestions sont informatives. Elles ne posent aucun diagnostic, ne prouvent pas de lien de cause à effet et ne remplacent pas les conseils d’un médecin, d’un diététicien ou d’un autre professionnel de santé.',
    'Connexion directe dans l’app iPhone':'Connexion directe dans l’application iPhone',
    'Mot de passe oublié ou compte créé avec un lien magique?':'Mot de passe oublié ou compte créé avec un lien magique ?',
    'Choisis si et quand l’application te rappelle de noter ton ressenti après un repas.':'Choisissez si et quand l’application vous rappelle de noter votre ressenti après un repas.',
    'Désactive ceci pour ne recevoir aucun rappel':'Désactivez cette option pour ne recevoir aucun rappel',
    'Connecte-toi afin que les repas et favoris soient enregistrés dans Supabase.':'Connectez-vous afin que vos repas et favoris soient enregistrés dans Supabase.',
    'Tu es hors ligne. Les changements seront synchronisés plus tard.':'Vous êtes hors ligne. Les modifications seront synchronisées ultérieurement.',
    'Répondre':'Répondre','Utiliser':'Utiliser','Limites importantes':'Limites importantes',
    '😊 Ressenti':'😊 Ressenti','⭐ Mes favoris':'⭐ Mes favoris','Observation personnelle':'Observation personnelle','Très faible':'Très faible','Faible':'Faible','Moyenne':'Moyenne','Bonne':'Bonne','Excellente':'Excellente'
  });



  // V3.7.0 — Sprint 2C : interface du moteur d’observations alimentaires.
  Object.assign(en, {
    'Observations alimentaires':'Food insights','Ce que tes repas semblent révéler':'What your meals may be revealing',
    'Nouvelle tendance détectée':'New trend detected','Tendance forte':'Strong trend','Tendance modérée':'Moderate trend','Tendance légère':'Slight trend',
    'Avec':'With','Sans':'Without','journées analysées':'days analyzed','journée analysée':'day analyzed',
    'Ton journal apprend encore':'Your journal is still learning',
    'Continue à remplir ton journal. Après quelques semaines, Énergie commencera à repérer des tendances personnelles entre tes repas et ton niveau d’énergie.':'Keep filling in your journal. After a few weeks, Énergie will begin noticing personal patterns between your meals and energy level.',
    'actuellement analysable':'currently analyzable','actuellement analysables':'currently analyzable',
    'journée analysable':'analyzable day','journées analysables':'analyzable days','documentée':'documented','documentées':'documented',
    'Ces observations comparent uniquement les journées de ton propre historique. Elles décrivent des associations possibles, ne prouvent aucune cause et ne constituent jamais un diagnostic.':'These insights compare only days from your own history. They describe possible associations, do not prove a cause, and never constitute a diagnosis.',
    'Pourquoi cette tendance apparaît-elle?':'Why does this trend appear?','À interpréter avec prudence':'Interpret with care',
    'Une association ne signifie pas que cet aliment ou cette catégorie est la cause du niveau d’énergie observé. Le sommeil, l’hydratation, les portions, le moment des repas et d’autres facteurs peuvent varier.':'An association does not mean that this food or category caused the observed energy level. Sleep, hydration, portions, meal timing, and other factors may vary.',
    'Comment cette observation est calculée':'How this insight is calculated',
    'Énergie classe les descriptions de repas par catégories, compare les journées avec et sans la catégorie, puis conserve seulement les écarts suffisamment nets avec assez de journées comparables.':'Énergie classifies meal descriptions into categories, compares days with and without the category, and keeps only sufficiently clear differences supported by enough comparable days.',
    'Le moteur préfère ne rien afficher lorsque les données sont insuffisantes ou que la différence est trop faible.':'The engine prefers to show nothing when there is not enough data or the difference is too small.',
    'Autres observations':'Other insights','Continue d’enregistrer tes repas pour obtenir d’autres observations personnelles.':'Keep logging meals to unlock other personal insights.'
  });
  Object.assign(frFR, {
    'Observations alimentaires':'Observations alimentaires','Ce que tes repas semblent révéler':'Ce que vos repas semblent révéler',
    'Nouvelle tendance détectée':'Nouvelle tendance détectée','Tendance forte':'Tendance forte','Tendance modérée':'Tendance modérée','Tendance légère':'Tendance légère',
    'Ton journal apprend encore':'Votre journal apprend encore',
    'Continue à remplir ton journal. Après quelques semaines, Énergie commencera à repérer des tendances personnelles entre tes repas et ton niveau d’énergie.':'Continuez à remplir votre journal. Après quelques semaines, Énergie commencera à repérer des tendances personnelles entre vos repas et votre niveau d’énergie.',
    'Ces observations comparent uniquement les journées de ton propre historique. Elles décrivent des associations possibles, ne prouvent aucune cause et ne constituent jamais un diagnostic.':'Ces observations comparent uniquement les journées de votre propre historique. Elles décrivent des associations possibles, ne prouvent aucune cause et ne constituent jamais un diagnostic.',
    'Pourquoi cette tendance apparaît-elle?':'Pourquoi cette tendance apparaît-elle ?',
    'Une association ne signifie pas que cet aliment ou cette catégorie est la cause du niveau d’énergie observé. Le sommeil, l’hydratation, les portions, le moment des repas et d’autres facteurs peuvent varier.':'Une association ne signifie pas que cet aliment ou cette catégorie est à l’origine du niveau d’énergie observé. Le sommeil, l’hydratation, les portions, l’heure des repas et d’autres facteurs peuvent varier.',
    'Énergie classe les descriptions de repas par catégories, compare les journées avec et sans la catégorie, puis conserve seulement les écarts suffisamment nets avec assez de journées comparables.':'Énergie classe les descriptions de repas par catégories, compare les journées avec et sans la catégorie, puis conserve uniquement les écarts suffisamment nets reposant sur assez de journées comparables.',
    'Continue d’enregistrer tes repas pour obtenir d’autres observations personnelles.':'Continuez à enregistrer vos repas pour obtenir d’autres observations personnelles.'
  });

  // V3.7.1 — Le cerveau d’Énergie.
  Object.assign(en, {
    'Le cerveau d’Énergie':'Énergie’s brain','Je fais connaissance avec toi':'I’m getting to know you','Le cerveau d’Énergie apprend encore':'Énergie’s brain is still learning',
    'Premières connexions détectées':'First connections detected','Mes observations gagnent en confiance':'My insights are gaining confidence','Ton journal est riche en données':'Your journal is rich in data',
    'Les premières tendances se préparent':'Your first trends are taking shape','Continue simplement à remplir ton journal. Le cerveau d’Énergie compare déjà tes journées, mais préfère attendre avant de montrer une observation trop fragile.':'Keep filling in your journal. Énergie’s brain is already comparing your days, but prefers to wait rather than show an insight that is too fragile.',
    'Analyse avancée':'Advanced analysis','La croissance continue avec chaque nouvelle journée.':'Growth continues with every new day.','avant les premières tendances':'until the first trends','pour renforcer les observations':'to strengthen insights','vers un journal riche':'toward a rich journal'
  });
  Object.assign(frFR, {
    'Je fais connaissance avec toi':'Je fais connaissance avec vous','Le cerveau d’Énergie apprend encore':'Le cerveau d’Énergie apprend encore','Premières connexions détectées':'Premières connexions détectées','Mes observations gagnent en confiance':'Mes observations gagnent en fiabilité','Ton journal est riche en données':'Votre journal est riche en données',
    'Les premières tendances se préparent':'Les premières tendances se préparent','Continue simplement à remplir ton journal. Le cerveau d’Énergie compare déjà tes journées, mais préfère attendre avant de montrer une observation trop fragile.':'Continuez simplement à remplir votre journal. Le cerveau d’Énergie compare déjà vos journées, mais préfère attendre avant d’afficher une observation trop fragile.'
  });

  const dict=locale==='en'?en:locale==='fr-FR'?frFR:{};
  const translate=s=>dict[s]||s;
  window.ENERGIE_I18N={locale,t:translateString,translateDOM:root=>translateDOM(root)};
  window.t=translateString;
  const nativeAlert=window.alert.bind(window),nativeConfirm=window.confirm.bind(window),nativePrompt=window.prompt.bind(window);
  window.alert=message=>nativeAlert(translateString(String(message)));
  window.confirm=message=>nativeConfirm(translateString(String(message)));
  window.prompt=(message,defaultValue)=>nativePrompt(translateString(String(message)),defaultValue);

  const NativeDTF=Intl.DateTimeFormat;
  Intl.DateTimeFormat=function(loc,opts){return new NativeDTF(loc==='fr-CA'?locale:loc,opts)};
  Intl.DateTimeFormat.prototype=NativeDTF.prototype;
  const nativeDate=Date.prototype.toLocaleDateString;
  Date.prototype.toLocaleDateString=function(loc,opts){return nativeDate.call(this,loc==='fr-CA'?locale:loc,opts)};

  function translateString(s){
    let out=translate(s);
    if(locale==='en'){
      const mealWord=x=>translate(x.charAt(0).toUpperCase()+x.slice(1)).toLowerCase();
      out=out
        .replace(/^(\d+)\/(\d+) repas principal(?:aux)?$/,(_,a,b)=>`${a}/${b} main meals`)
        .replace(/^(\d+) entrée(s?) aujourd’hui$/,(_,n)=>`${n} entr${n==='1'?'y':'ies'} today`)
        .replace(/^(\d+) réponse(s?) en attente$/,(_,n)=>`${n} pending response${n==='1'?'':'s'}`)
        .replace(/^Après (déjeuner|dîner|souper|collation|boisson) · (.+)$/i,(_,m,time)=>`After ${mealWord(m)} · ${time}`)
        .replace(/^Dernier ressenti : /,'Latest feeling: ')
        .replace(/^Ajouter (Déjeuner|Dîner|Souper|Collation|Boisson)$/i,(_,m)=>`Add ${translate(m)}`)
        .replace(/^Modifier (Déjeuner|Dîner|Souper|Collation|Boisson)$/i,(_,m)=>`Edit ${translate(m)}`)
        .replace(/^(\d+) heure(s?)$/,(_,n)=>`${n} hour${n==='1'?'':'s'}`)
        .replace(/^(\d+) à synchroniser$/,(_,n)=>`${n} to sync`)
        .replace(/^(\d+) repas$/,(_,n)=>`${n} meal${n==='1'?'':'s'}`)
        .replace(/^(\d+) journée(s?)$/,(_,n)=>`${n} day${n==='1'?'':'s'}`)
        .replace(/^(\d+) mois$/,(_,n)=>`${n} month${n==='1'?'':'s'}`)
        .replace(/^(\d+) jour(s?) de suivi$/,(_,n)=>`${n} day${n==='1'?'':'s'} tracked`)
        .replace(/^Depuis le (.+)$/,'Since $1')
        .replace(/^(\d+) collation(s?) notée(s?)$/,(_,n)=>`${n} snack${n==='1'?'':'s'} logged`)
        .replace(/^Ressenti (\d+) sur 5$/, 'Feeling $1 out of 5')
        .replace(/^Comment te sens-tu après ton (.+) \?$/,(_,meal)=>`How do you feel after your ${mealWord(meal)}?`)
        .replace(/^Supprimer « (.+) » des favoris\?$/,(_,name)=>`Remove “${name}” from favorites?`)
        .replace(/^Semaine du (.+) au (.+)$/,(_,a,b)=>`Week of ${a} to ${b}`)
        .replace(/^(\d+) carte(s?)$/,(_,n)=>`${n} card${n==='1'?'':'s'}`)
        .replace(/^(\d+) copie\(s\) locale\(s\) de sécurité\.$/,(_,n)=>`${n} local backup cop${n==='1'?'y':'ies'}.`)
        .replace(/^Basé sur (\d+) repas enregistrés ce jour de la semaine\.$/,(_,n)=>`Based on ${n} meals logged on this day of the week.`)
        .replace(/^Basé sur (\d+) repas enregistrés\.$/,(_,n)=>`Based on ${n} logged meals.`)
        .replace(/^Tu as enregistré (\d+) repas\. Ce suivi régulier donnera davantage de contexte aux tendances futures\.$/,(_,n)=>`You logged ${n} meals. Continued tracking will add more context to future patterns.`)
        .replace(/^Tu enregistres tes repas vers (.+) en moyenne\.$/,(_,time)=>`You usually log meals around ${time}.`)
        .replace(/^Le (.+), ton énergie avant les repas est en moyenne de (.+)\/5 dans les données disponibles\.$/,(_,day,val)=>`On ${day}, your average energy before meals is ${val}/5 in the available data.`)
        .replace(/^L’énergie notée avant les repas est plutôt faible pour cette journée, selon les données enregistrées\.$/,'Energy before meals was relatively low on this day, based on your entries.')
        .replace(/^L’énergie notée avant les repas est plutôt élevée pour cette journée\. Cela ne permet pas d’en déterminer la cause\.$/,'Energy before meals was relatively high on this day. This does not identify a cause.')
        .replace(/^(\d+) repas au total$/,(_,n)=>`${n} total meal${n==='1'?'':'s'}`)
        .replace(/^(\d+) entrée(?:s)? aujourd’hui$/,(_,n)=>`${n} entr${n==='1'?'y':'ies'} today`)
        .replace(/^(\d+) réponse(?:s)? en attente$/,(_,n)=>`${n} pending response${n==='1'?'':'s'}`)
        .replace(/^(\d+) copie\(s\) locale\(s\) de sécurité\.$/,(_,n)=>`${n} local backup cop${n==='1'?'y':'ies'}.`)
        .replace(/^Utilisé (\d+) fois$/,(_,n)=>`Used ${n} time${n==='1'?'':'s'}`)
        .replace(/^Confiance (.+)$/i,(_,level)=>`Confidence ${translateString(level).toLowerCase()}`)
        .replace(/^Énergie avant (.+)\/5$/,(_,v)=>`Energy before ${v}/5`)
        .replace(/^Après (.+) · (.+)$/,(_,meal,date)=>`After ${translateString(meal)} · ${date}`)
        .replace(/^Depuis le (.+)$/i,(_,date)=>`Since ${date}`)
        .replace(/^(\d+) jour(?:s)? de suivi$/,(_,n)=>`${n} day${n==='1'?'':'s'} tracked`)
        .replace(/^(\d+) journée(?:s)?$/,(_,n)=>`${n} day${n==='1'?'':'s'}`)
        .replace(/^(\d+) mois$/,(_,n)=>`${n} month${n==='1'?'':'s'}`)
        .replace(/^(\d+) repas$/,(_,n)=>`${n} meal${n==='1'?'':'s'}`)
        .replace(/^Supprimer (.+)$/,(_,x)=>`Delete ${translateString(x)}`)
        .replace(/^Avant tes repas « (.+) », ton énergie enregistrée est en moyenne de (.+)\/5\. Cela décrit ton historique sans expliquer la cause\.$/,(_,meal,val)=>`Before ${translateString(meal).toLowerCase()} meals, your logged energy averages ${val}/5. This describes your history without explaining the cause.`)
        .replace(/^Le type de repas le plus souvent enregistré est « (.+) »\. Cette information est descriptive seulement\.$/,(_,meal)=>`The most frequently logged meal type is “${translateString(meal)}”. This information is descriptive only.`)
        .replace(/^Ajouter (.+)$/,(_,x)=>`Add ${translateString(x)}`)
        .replace(/^Modifier (.+)$/,(_,x)=>`Edit ${translateString(x)}`);
    } else if(locale==='fr-FR'){
      out=out.replace(/^Ton parcours$/,'Votre parcours')
        .replace(/^Observe tes habitudes sans jugement$/,'Observez vos habitudes')
        .replace(/^Depuis le (.+)$/,'Depuis le $1')
        .replace(/^(\d+) journée(s?)$/,(_,n)=>`${n} jour${n==='1'?'':'s'}`);
    }
    return out;
  }
  function translateDOM(root=document){
    const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
    const nodes=[];while(walker.nextNode())nodes.push(walker.currentNode);
    nodes.forEach(n=>{const raw=n.nodeValue,trim=raw.trim();if(!trim)return;const tr=translateString(trim);if(tr!==trim)n.nodeValue=raw.replace(trim,tr)});
    root.querySelectorAll?.('[placeholder],[aria-label],[title]').forEach(el=>['placeholder','aria-label','title'].forEach(a=>{if(el.hasAttribute(a))el.setAttribute(a,translateString(el.getAttribute(a)))}));
    ensureLanguageSelector();
  }
  function ensureLanguageSelector(){
    const app=document.querySelector('#app');if(!app||!document.querySelector('#waterGoal')||document.querySelector('#languageSettingCard'))return;
    const card=document.createElement('section');card.className='card';card.id='languageSettingCard';
    card.innerHTML=`<div class="settings-row"><div><h3>${translate('Langue')}</h3><p class="muted small">${translate('Langue de l’application')}</p></div><select id="languageSelect" aria-label="${translate('Langue de l’application')}"><option value="fr-CA">${translate('Français (Canada)')}</option><option value="fr-FR">${translate('Français (France)')}</option><option value="en">English</option></select></div>`;
    const stack=app.querySelector('.stack');const target=[...stack.children].find(x=>x.textContent.includes('Objectif')||x.textContent.includes('Water goal'));target?.after(card);
    const sel=card.querySelector('select');sel.value=locale;sel.addEventListener('change',()=>{localStorage.setItem('energieLocale',sel.value);location.reload()});
  }
  const obs=new MutationObserver(ms=>ms.forEach(m=>{if(m.type==='characterData'){const raw=m.target.nodeValue,trim=raw.trim();if(trim){const tr=translateString(trim);if(tr!==trim)m.target.nodeValue=raw.replace(trim,tr)}}m.addedNodes.forEach(n=>{if(n.nodeType===1)translateDOM(n);else if(n.nodeType===3){const raw=n.nodeValue,trim=raw.trim();if(trim){const tr=translateString(trim);if(tr!==trim)n.nodeValue=raw.replace(trim,tr)}}})}));
  document.addEventListener('DOMContentLoaded',()=>{translateDOM(document);obs.observe(document.body,{childList:true,subtree:true,characterData:true})});
})();
